# Release Notes

## 3.0.0
 Stable release

## 3.0.0-rc2
- Limiter: added new ENVs
- Notifier: added new ENVs
- Backend: updated ENVs
- Worker-Api: changed default pod port
- Fluentd: removed
- Resources: Updated request and limit
- Service naming: Unified service name across chart

## 3.0.0-rc1
- Backend: added new ENVs
- Frontend: added new ENVs
- Notifier: added new deployment and service
- Trace: added new deployment and service
- Tunnel-proxy: added new deployment and service

### Changes

- Backend: Post-install: added missing ENVs

## 2.1.17

### Changes

- Backend: Post-install: added missing ENVs

## 2.1.16

### Changes

- Metrics-collector: added HA mode for RabbitMQ and MongoDB
- Backend: ENV: removed UDP_LOGGER_URL and WORKER_DEFAULT_PORT
- Limiter: ENV: removed UDP_LOGGER_URL
- Multi-Counter: ENV: removed UDP_LOGGER_URL
- Backend: added post install job

## 2.1.15

### Changes

- Metrics-collector: added deployment

## 2.1.14

### Changes

- Helm: updated dependents charts (Grafana, Loki, Alloy)
- Helm: Loki: increased max limits for processing bigger logs

## 2.1.13

### Changes

- Helm: Alloy updated processing pipeline
- Helm: Loki optimized resources

## 2.1.12

### Changes

- Helm: FIX: Alloy config is created only when Alloy is enabled

## 2.1.11

### Changes

- Helm: added Grafana, Loki and Alloy as a optional dependency
- Helm: imageRegistry renamed to orchestyImageRegistry


## 2.1.10

### Changes

- Frontend: Added the option to change service port
- Backend: Added the option to change service port
- StartingPoint: Added the option to change service port

- Helm: added Valkey as a optional dependency

## 2.1.9

### Changes

- Worker: Added the option to add ports for sidecar containers

## 2.1.8

### Changes

- Worker: Added the option to add sidecar containers
- Worker: Added the option to add livenessProbe and readinessProbe

## 2.1.7

### Changes

- Helm: Added the option to set resource quota for namespace
- Helm: Added the option to set timezone
- Worker: Added the option to set resources for each worker separately
- Worker: Added the option to set replicas for each worker separately

## 2.1.6

### Changes

- Helm: updated resource limit for Backend

## 2.1.5

### Changes

- Helm: added global orchestyVersion variable

## 2.1.4

### Changes

- MarketplaceUI: added support for Custom branding
- TopologyAPI: added support for extra specs

## 2.1.3

### Changes

- Backend, Frontend, StartingPoint, MarketplaceUI: added support for Service.NodePort

## 2.1.2

### Changes

- Backend: removed prefix from TOPOLOGY_API_DSN value

## 2.1.1

### Changes

- Worker: removed prefix from service name

## 2.1.0

### Changes

- Worker: removed deprecated config for set up a worker

## 2.0.3

### Changes

- Worker-api: added metricsDb env
- Backend: added limiter env
- Limiter - service: removed deprecated port (3333)
- Added support for multiple workers

## 2.0.2

### Changes

- FluentD: added correct port number for TCP
- Updated default resources config

## 2.0.1

### Changes

- Chart bug fixes

## 2.0.0

### Breaking changes:

- Changed default Orchesty version to new major version 2.0.0

### Changes

- Added `worker-api` service and deployment
- Added configuration option `global.worker_api_url` 
